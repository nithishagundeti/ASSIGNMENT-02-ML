# Assignment2

Phanindra Dokku Video Link : https://drive.google.com/file/d/1ZU4ANVLWsUoq8ywSKbir85Eoi99bFqlC/view?usp=drive_link

Data CSV is for pandas part of the code Train and test in dataset folder are training and testing csv files for Titanic dataset Glass CSV is for Glass Dataset
